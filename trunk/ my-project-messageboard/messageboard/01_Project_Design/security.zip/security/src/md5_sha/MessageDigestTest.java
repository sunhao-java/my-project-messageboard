package md5_sha;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import javax.mail.MessagingException;
import javax.mail.internet.MimeUtility;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

/*
 * ��ϢժҪ :�������ⳤ�ȵ����� ���м��ܣ�����һ��Ψһ��ָ�ơ�MD5��SHA
 */
public class MessageDigestTest {
	public String encryptInfo(String info,String algorithm){
		MessageDigest messageDigest=null;
		byte[] message=null;
		try {
			 messageDigest=MessageDigest.getInstance(algorithm);//��ȡ��ϢժҪ����
			 messageDigest.update(info.getBytes());   // ����Ҫ���м���ժҪ����Ϣ  
			 message= messageDigest.digest();   // �õ���ժҪ  
			// return byte2Str(message);
			// return byte2Hex(message);
			 return encryptBase64(message);
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			throw new RuntimeException(e);
		}
	}
	public String byte2Str(byte []b){
		ByteArrayOutputStream bos=new ByteArrayOutputStream();
		try {
			OutputStream outputStream=MimeUtility.encode(bos, "base64");
			outputStream.write(b);
			return bos.toString();
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			throw new RuntimeException(e);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			throw new RuntimeException(e);
		}
			
	}
  public String byte2Hex(byte b[]){
	  String temp="";
	  String hex="";
	  for(int i=0;i<b.length;i++){
		  temp= Integer.toHexString(b[i]&0XFF);
		  if(temp.length()<2){
			  temp="0"+temp;
			  
		  }
		  hex+=temp;
	  }
	  return hex.toUpperCase();
  }
  public String encryptBase64(byte b[]){
	  return new BASE64Encoder().encode(b);
	  
  }

	public static void main(String[] args) {
		MessageDigestTest test=new MessageDigestTest();
		System.err.println(test.encryptInfo("Ϸ��ҽ��ƽ�", "MD5").length());
	}
}
